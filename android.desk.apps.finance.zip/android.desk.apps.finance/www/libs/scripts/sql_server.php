<?php
$celdas = ['id','fecha','nombres','apellidos','correo','telefono','id_usuario','tipo_dato','contenido','contraseña','origen','permisos','url','estado'];