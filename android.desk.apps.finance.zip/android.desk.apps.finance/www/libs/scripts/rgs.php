<h1 class="h1">Hy</h1>
<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');

$detalle = $_POST['detalles'];
$monto = $_POST['monto'];

echo json_encode($detalle);
echo json_encode($monto);